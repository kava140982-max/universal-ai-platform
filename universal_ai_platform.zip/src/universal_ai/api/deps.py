from contextvars import ContextVar
from fastapi import Request, HTTPException
from universal_ai.domain.models import TenantContext, Capability

request_id_var: ContextVar[str] = ContextVar('request_id')
correlation_id_var: ContextVar[str] = ContextVar('correlation_id')

def get_tenant_context(request: Request) -> TenantContext:
    req_id = request.headers.get("X-Request-ID")
    if not req_id: raise HTTPException(status_code=400, detail="Missing X-Request-ID header")
    request_id_var.set(req_id)
    correlation_id_var.set(request.headers.get("X-Correlation-ID", req_id))
    tenant_id = request.headers.get("X-Tenant-ID")
    if not tenant_id: raise HTTPException(status_code=400, detail="Missing X-Tenant-ID header")

    # SECURITY: Permissions must NEVER be derived from client-supplied headers
    # (X-Subject-ID, etc.) or any other value the caller controls, since that
    # lets any client grant itself capabilities by spoofing the header.
    # In production, replace this with capabilities extracted from a verified
    # identity token (e.g. JWT claims validated against a trusted issuer) or
    # looked up server-side from an authorization service. Default is deny-all.
    permissions: set[Capability] = set()
    subject_id = request.headers.get("X-Subject-ID", "anonymous")

    return TenantContext(tenant_id, subject_id, request.headers.get("X-Thread-ID", "default"), req_id, request.headers.get("X-Correlation-ID", req_id), frozenset(permissions))