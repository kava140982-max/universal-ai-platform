# Universal Modular AI Platform
Hexagonale Architektur, Pydantic v2, Python 3.12+.
## Start
pip install -r requirements-dev.txt  # runtime + test deps
PYTHONPATH=src pytest -q
PYTHONPATH=src uvicorn universal_ai.main:app --reload

For a production install use `pip install -r requirements.txt` (runtime deps only).